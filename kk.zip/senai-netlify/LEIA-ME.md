# Batalha entre Turmas · SENAI

Estrutura:
- public/index.html  → front-end (placar, equipes, rodadas)
- netlify/functions/api.mjs → back-end (regras, pontos, juiz com senha)
- Dados guardados no Netlify Blobs (sem banco externo)

Publicar (escolha UMA forma):
A) GitHub: suba esta pasta para um repositório e conecte no Netlify (Add new site → Import from Git).
   NÃO use "netlify deploy" como build command. O netlify.toml já define tudo.
B) Computador: dentro da pasta, rode `npx netlify-cli deploy --prod` (pede login no navegador).

Depois:
1. Site configuration → Environment variables → crie JUIZ_SENHA com a senha do juiz.
2. Faça um novo deploy (Deploys → Trigger deploy) e compartilhe o link do site.
