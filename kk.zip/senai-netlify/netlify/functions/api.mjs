import { getStore } from "@netlify/blobs";

const fresh = () => ({
  a: { n: "Equipe Azul", s: 0 }, b: { n: "Equipe Vermelha", s: 0 },
  r: { id: 0, q: "", open: false, end: 0 },
  log: [], players: {}, answers: {},
});
const txt = (v, n) => String(v ?? "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, n);
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });

export default async (req) => {
  if (req.method !== "POST") return json({ ok: true });
  const b = await req.json().catch(() => ({}));
  const store = getStore({ name: "batalha", consistency: "strong" });
  const S = (await store.get("state", { type: "json" })) || fresh();
  const now = Date.now();
  const pid = txt(b.pid, 64);
  const host = !!process.env.JUIZ_SENHA && b.senha === process.env.JUIZ_SENHA;
  let dirty = false;
  const log = (m) => { S.log.unshift(m); S.log = S.log.slice(0, 6); };
  const teamOk = (t) => t === "a" || t === "b";
  const count = (t, except) => Object.entries(S.players).filter(([id, p]) => p.team === t && id !== except).length;

  if (S.r.open && now >= S.r.end) { S.r.open = false; dirty = true; }

  switch (b.action) {
    case "join": {
      if (pid && teamOk(b.team) && count(b.team, pid) < 5) {
        S.players[pid] = { name: txt(b.name, 20) || "Jogador", team: b.team }; dirty = true;
      }
      break;
    }
    case "leave": if (S.players[pid]) { delete S.players[pid]; dirty = true; } break;
    case "answer": {
      const p = S.players[pid];
      if (p && S.r.open && now < S.r.end && !S.answers[pid]) {
        S.answers[pid] = { name: p.name, team: p.team, text: txt(b.text, 120), ok: null };
        S[p.team].s += 1; log(`${S[p.team].n} +1 — ${p.name} participou`); dirty = true;
      }
      break;
    }
    case "open": if (host && txt(b.q, 200)) {
      const secs = Math.min(120, Math.max(10, +b.secs || 30));
      S.r = { id: S.r.id + 1, q: txt(b.q, 200), open: true, end: now + secs * 1000 };
      S.answers = {}; log("Nova rodada aberta"); dirty = true;
    } break;
    case "close": if (host) { S.r.open = false; dirty = true; } break;
    case "judge": if (host) {
      const a = S.answers[b.target];
      if (a) {
        if (b.ok === true && a.ok !== true) { S[a.team].s += 10; log(`${S[a.team].n} +10 — ${a.name} acertou`); }
        if (b.ok === false && a.ok === true) { S[a.team].s -= 10; log(`${S[a.team].n} −10 (correção)`); }
        a.ok = b.ok === true; dirty = true;
      }
    } break;
    case "adj": if (host && teamOk(b.team)) {
      const d = Math.max(-10, Math.min(10, +b.delta || 0));
      S[b.team].s += d; log(`${S[b.team].n} ${d > 0 ? "+" : "−"}${Math.abs(d)} (juiz)`); dirty = true;
    } break;
    case "reset": if (host) {
      S.a.s = 0; S.b.s = 0; S.log = []; S.answers = {}; S.r.open = false; dirty = true;
    } break;
  }
  if (dirty) await store.setJSON("state", S);

  return json({
    now, host, a: S.a, b: S.b, r: S.r, log: S.log,
    players: Object.entries(S.players).map(([id, p]) => ({ id, name: p.name, team: p.team })),
    mine: !!S.answers[pid],
    answers: host ? Object.entries(S.answers).map(([id, a]) => ({ id, ...a })) : undefined,
  });
};
export const config = { path: "/api" };
